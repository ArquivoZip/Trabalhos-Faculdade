#include <stdio.h>

int main ()
{
    int numero;
    printf ("Digite um número: ");
    scanf ("%i", &numero);
    
    switch(numero %2){
        
    case 0:
    printf ("Par");
    
    break;
    
    default:
    
    printf ("Ímpar");
    
    break;
    }
}
