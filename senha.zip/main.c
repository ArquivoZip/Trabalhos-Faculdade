#include <stdio.h>

int main()
{
    
    int new,password;
    
    while ( new == password )
    {
        printf("Digite a sua nova senha: \n");
        scanf("%i", &new );
        printf("Digite sua senha: \n");
        scanf("%i", &password);
        
        if( new != password )
        {
            printf("Senha Incorreta! \n");
           
        }
        
        else
        {
            printf("Senha Correta! \n");
        }
        
       
    }
    
    
}