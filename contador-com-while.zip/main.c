#include <stdio.h>

int main()
{
  int num = 0;
        while (num < 40){
    num++;
    printf ("%d ",num);
    
}

    return 0;
}