#include <stdio.h>

int main()
{
char vogal;

printf ("digite uma letra: \n");
scanf("%c", &vogal);
switch (vogal)
{
case 'a':
printf ("é uma vogal");
break;

case 'e':
printf ("é uma vogal");
break;

case 'i':
printf ("é uma vogal");
break;

case 'o':
printf ("é uma vogal");
break;

case 'u':
printf ("é uma vogal");

break;

default:
printf("é uma consoante");
break;
}

}