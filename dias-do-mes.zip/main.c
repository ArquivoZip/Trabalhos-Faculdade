#include <stdio.h>

int main()
{
int mes;

printf ("Insira o mês: \n");
scanf("%i", &mes);
switch (mes)
{
case 02:
printf ("Tem 28 dias");
break;

case 04:
printf ("Tem 30 dias");
break;

case 06:
printf ("Tem 30 dias");
break;

case 9:
printf ("Tem 30 dias");
break;

case 11:
printf ("Tem 30 dias");
break;

case 01:
printf ("Tem 31 dias");
break;

case 03:
printf ("Tem 31 dias");
break;

case 05:
printf ("Tem 31 dias");
break;

case 07:
printf ("Tem 31 dias");
break;

case 8:
printf ("Tem 31 dias");
break;

case 10:
printf ("Tem 31 dias");
break;

case 12:
printf ("Tem 31 dias");
break;

default:
printf("mês invalido");
break;

}
}