#include <stdio.h>

int main() {
    int cont = 1;
   while(cont >=1 && cont<= 12) {
       
    printf("%i - Janeiro \n", cont);
     cont++;
    printf("%i - Fevereiro \n", cont);
     cont++;
    printf("%i - Março \n", cont);
     cont++;
    printf("%i - Abril \n", cont);
     cont++;
    printf("%i - Maio \n", cont);
     cont++;
    printf("%i - Junho \n", cont);
     cont++;
    printf("%i - Julho \n", cont);
     cont++;
    printf("%i - Agosto \n", cont);
     cont++;
    printf("%i - Setembro \n", cont);
     cont++;
    printf("%i - Outubro \n", cont);
     cont++;
    printf("%i - Novembro \n", cont);
     cont++;
    printf("%i - Dezembro \n", cont);
     cont++;
   
   }
}