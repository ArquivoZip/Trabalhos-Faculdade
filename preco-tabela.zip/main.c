#include <stdio.h>

int main()
{
    int  cod;
    float quant;
    
     printf("Cachorro Quente - 100 \n");
     printf("Bauru Simples - 101 \n");
     printf("Bauru com Ovo - 102 \n");
     printf("Hamburguer - 103 \n");
     printf("Cheeseburguer - 104 \n");
     printf("Suco - 105 \n");
     printf("Refrigerante - 100 \n \n");
     
    printf("Digite o codigo: \n");
    scanf("%i", &cod);
    printf("Digite a quantidade: \n");
    scanf("%f", &quant);
    
    switch(cod)
    {
        case 100: 
        printf("%f a pagar: \n", quant * 1.2); 
        break;
        
        case 101:
        printf("%f a pagar: \n", quant * 1.3);
        break;
        
        case 102:
        printf("%f a pagar: \n", quant * 1.5);
        break;
        
        case 103:
        printf("%f a pagar: \n", quant * 1.2);
        break;
        
        case 104:
        printf("%f a pagar: \n", quant * 1.7);
        break;
        
        case 105:
        printf("%f a pagar: \n", quant * 2.2);
        break;
        
        case 106:
        printf("%f a pagar: \n", quant * 1.0);
        break; 
        
        default:
        printf("esse codigo não existe");
        break;
        
    }
    
    


   
}