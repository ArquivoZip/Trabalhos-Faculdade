#include <stdio.h>
#include <stdbool.h> 
int main()
{
    bool controle = false;
    int n1;
    
    while(controle == false) 
    {
        printf("Digite um número de 1 a 10: ");
        scanf("%i", &n1);
        
        if (n1 >= 1 && n1 <= 10) 
        {
            int contador; 
            while(contador <= 10)  
            {
                printf("%i X %i = %i \n", n1, contador, n1 * contador); 
                contador++;  
                controle = true; 
            }
            
        }
        else
        {
            printf("Número inválido! ");
            
        }
    }
}